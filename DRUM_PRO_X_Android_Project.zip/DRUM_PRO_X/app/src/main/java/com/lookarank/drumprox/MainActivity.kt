package com.lookarank.drumprox

import android.app.Activity
import android.media.AudioAttributes
import android.media.SoundPool
import android.os.Bundle
import android.graphics.Color
import android.view.Gravity
import android.view.View
import android.widget.*
import android.graphics.Typeface
import android.graphics.drawable.GradientDrawable
import kotlin.math.max
import kotlin.math.min

class MainActivity : Activity() {
    private lateinit var soundPool: SoundPool
    private val soundIds = IntArray(10)
    private val loaded = BooleanArray(10)
    private var masterVolume = 0.85f
    private var tone = 1.0f
    private var selectedKit = 0
    private val padNames = arrayOf("KICK", "SNARE", "HI-HAT", "TOM 1", "TOM 2",
        "FLOOR TOM", "CRASH 1", "CRASH 2", "RIDE", "PERC")
    private val kitNames = arrayOf("ACOUSTIC", "ROCK", "ELECTRONIC", "JAZZ")
    private lateinit var status: TextView
    private lateinit var kitLabel: TextView

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        window.statusBarColor = Color.rgb(10, 14, 22)
        window.navigationBarColor = Color.rgb(10, 14, 22)
        val attrs = AudioAttributes.Builder()
            .setUsage(AudioAttributes.USAGE_GAME)
            .setContentType(AudioAttributes.CONTENT_TYPE_MUSIC).build()
        soundPool = SoundPool.Builder().setMaxStreams(12).setAudioAttributes(attrs).build()
        for (i in 0..9) {
            val descriptor = assets.openFd("sounds/pad${i + 1}.wav")
            soundIds[i] = soundPool.load(descriptor, 1)
            descriptor.close()
        }
        soundPool.setOnLoadCompleteListener { _, sampleId, statusCode ->
            if (statusCode == 0) for (i in soundIds.indices) if (soundIds[i] == sampleId) loaded[i] = true
        }
        buildUi()
    }

    private fun buildUi() {
        val bg = Color.rgb(10, 14, 22)
        val panel = Color.rgb(22, 29, 42)
        val accent = Color.rgb(0, 210, 180)
        val root = LinearLayout(this).apply {
            orientation = LinearLayout.VERTICAL
            setPadding(16, 18, 16, 14)
            setBackgroundColor(bg)
        }
        val title = TextView(this).apply {
            text = "DRUM PRO X"
            textSize = 27f; setTextColor(Color.WHITE); typeface = Typeface.DEFAULT_BOLD
            gravity = Gravity.CENTER
        }
        root.addView(title, LinearLayout.LayoutParams(-1, 46))
        val sub = TextView(this).apply {
            text = "10-PAD ELECTRONIC DRUM MODULE"
            textSize = 11f; setTextColor(accent); gravity = Gravity.CENTER
        }
        root.addView(sub, LinearLayout.LayoutParams(-1, 24))

        val kitRow = LinearLayout(this).apply { orientation = LinearLayout.HORIZONTAL; gravity = Gravity.CENTER_VERTICAL }
        kitLabel = TextView(this).apply {
            text = "KIT: ${kitNames[selectedKit]}"; textSize = 14f; setTextColor(Color.WHITE)
            typeface = Typeface.DEFAULT_BOLD
        }
        kitRow.addView(kitLabel, LinearLayout.LayoutParams(0, 48, 1f))
        val kitButton = Button(this).apply {
            text = "CHANGE KIT"; setOnClickListener { selectedKit = (selectedKit + 1) % kitNames.size
                kitLabel.text = "KIT: ${kitNames[selectedKit]}"
                status.text = "${kitNames[selectedKit]} kit selected (sample set preview)"
            }
        }
        kitRow.addView(kitButton)
        root.addView(kitRow)

        val grid = GridLayout(this).apply { columnCount = 2; rowCount = 5; useDefaultMargins = true }
        for (i in 0..9) {
            val pad = TextView(this).apply {
                text = "${i + 1}\n${padNames[i]}"
                textSize = 16f; typeface = Typeface.DEFAULT_BOLD
                gravity = Gravity.CENTER; setTextColor(Color.WHITE)
                background = rounded(if (i == 0 || i == 1) Color.rgb(28, 92, 105) else panel, 18)
                isClickable = true; isFocusable = true
                setOnClickListener { playPad(i); status.text = "PLAYING: ${padNames[i]}" }
            }
            val lp = GridLayout.LayoutParams().apply {
                width = 0; height = 0
                columnSpec = GridLayout.spec(i % 2, 1f)
                rowSpec = GridLayout.spec(i / 2, 1f)
                setMargins(5, 5, 5, 5)
            }
            grid.addView(pad, lp)
        }
        root.addView(grid, LinearLayout.LayoutParams(-1, 0, 1f))

        val controlsTitle = TextView(this).apply {
            text = "SOUND CONTROLS"; setTextColor(accent); textSize = 13f
            typeface = Typeface.DEFAULT_BOLD
        }
        root.addView(controlsTitle)
        root.addView(makeSeek("MASTER VOLUME", 85) { value -> masterVolume = value / 100f })
        root.addView(makeSeek("TONE / PITCH", 50) { value -> tone = 0.75f + (value / 100f) * 0.5f })
        status = TextView(this).apply {
            text = "READY  •  Tap a pad to test sounds"
            textSize = 12f; setTextColor(Color.LTGRAY); gravity = Gravity.CENTER
        }
        root.addView(status, LinearLayout.LayoutParams(-1, 34))
        val footer = TextView(this).apply {
            text = "V1.0  |  PHONE PAD TEST MODE  |  TRIGGER INPUTS: COMING NEXT"
            textSize = 9f; setTextColor(Color.GRAY); gravity = Gravity.CENTER
        }
        root.addView(footer)
        setContentView(root)
    }

    private fun makeSeek(label: String, initial: Int, changed: (Int) -> Unit): View {
        val box = LinearLayout(this).apply { orientation = LinearLayout.VERTICAL }
        val text = TextView(this).apply { this.text = "$label  $initial%"; textSize = 11f; setTextColor(Color.WHITE) }
        val seek = SeekBar(this).apply {
            max = 100; progress = initial
            setOnSeekBarChangeListener(object : SeekBar.OnSeekBarChangeListener {
                override fun onProgressChanged(sb: SeekBar?, value: Int, fromUser: Boolean) {
                    text.text = "$label  $value%"; changed(value)
                }
                override fun onStartTrackingTouch(sb: SeekBar?) {}
                override fun onStopTrackingTouch(sb: SeekBar?) {}
            })
        }
        box.addView(text); box.addView(seek)
        return box
    }

    private fun playPad(index: Int) {
        if (loaded[index]) soundPool.play(soundIds[index], masterVolume, masterVolume, 1, 0, tone)
    }

    private fun rounded(color: Int, radius: Int): GradientDrawable =
        GradientDrawable().apply { setColor(color); cornerRadius = radius.toFloat(); setStroke(2, Color.rgb(0, 170, 155)) }

    override fun onDestroy() {
        super.onDestroy()
        soundPool.release()
    }
}
