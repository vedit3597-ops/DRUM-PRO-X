# DRUM PRO X (starter Android project)

This is Version 1.0: a phone-based 10-pad drum module preview. Tap the on-screen pads to test the sound engine.

## Important
- The included WAVs are generated starter/demo sounds, not studio-recorded acoustic drum samples.
- This version does **not** yet read physical electronic drum triggers. That requires a compatible USB trigger interface and device-specific testing, which can be added as a later stage.
- Tone/Pitch and master volume controls are included. Kit selector currently changes the kit label; separate multisample kits, per-pad editing, MIDI, recording, and external trigger mapping are planned for later versions.

## Build
Requires Android Gradle Plugin 8.6.1, Gradle 8.x, and JDK 17.
Run `gradle assembleDebug`. APK output: `app/build/outputs/apk/debug/app-debug.apk`.
